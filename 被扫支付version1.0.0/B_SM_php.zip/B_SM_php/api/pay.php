<?php 
    require_once '../conf/config.php';
    require_once '../services/Services.php';
    /**
     * 
     * @author Jupiter
     *
     * 消费接口
     * 用于对支付信息进行重组和签名，并将请求发往现在支付
     * 
     */
    class Pay{
        public function main(){
            $req=array();
			$req["appId"]=Config::$appId;
			$req["deviceType"]=Config::TRADE_DEVICE_TYPE;
			$req["funcode"]=Config::TRADE_FUNCODE;
			$req["mhtCharset"]=Config::TRADE_CHARSET;
			$req["mhtCurrencyType"]=Config::TRADE_CURRENCYTYPE;
			$req["mhtOrderAmt"]=$_GET["mhtOrderAmt"];
			$req["mhtOrderDetail"]=$_GET["mhtOrderDetail"];
			$req["mhtOrderName"]=$_GET["mhtOrderName"];
			$req["channelAuthCode"]=$_GET["channelAuthCode"];
			$req["mhtOrderNo"]=date("YmdHis");
			$req["mhtOrderStartTime"]=date("YmdHis");
            $req["mhtOrderTimeOut"]=Config::$trade_time_out;
            $req["mhtOrderType"]=Config::TRADE_TYPE;
			$req["mhtReserved"]="test";
            $req["mhtSignType"]=Config::TRADE_SIGN_TYPE;
			$req["notifyUrl"]=Config::$back_notify_url;
			$req["payChannelType"]=27;//12 支付宝  //13 微信   //27 银联   
			$req["version"]="1.0.0";
            $req["mhtSignature"]=Services::buildSignature($req);
			
            $req_str=Services::trade($req);
            header("Location:".Config::TRADE_URL."?".$req_str);
		echo"$req_str";
        }
    }
    $p=new Pay();
    $p->main();