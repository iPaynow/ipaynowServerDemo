package sc.com.sms;
public class smsConfig {
	
	/**
	 * 【测试环境】
	 **/
	public final static String appId  = "1441071499740581";
	public final static String md5Key = "DK96gnOB7EmVDDaHgLTLEZqVgP0H0nML";
	public final static String des3Key = "DWyMJJiPjnntDXrFD5D5hf3w";
	public final static String url = "https://dby.ipaynow.cn/sms";
	
}




	
	
	
	
	
