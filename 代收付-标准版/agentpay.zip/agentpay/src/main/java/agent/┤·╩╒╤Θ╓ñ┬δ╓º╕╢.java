package main.java.agent;

import main.java.util.DateUtil;
import main.java.util.HttpPost;

import java.util.*;

/**
 * 
 * @author WGH
 * Date: 16-10-13
 * Time: 上午10:40
 */


public class 代收验证码支付 {

    public static void main(String[] args){
        Packages packages = new Packages();
        Unpack unpack = new Unpack();
        Map<String,String> map = new HashMap<String, String>();
        try {
            String requestReport = "";
            Date date = new Date();

            String funcode = "AP10";
            String mhtOrderNo = (int)(Math.random()*1000+1000)+""+(int)(Math.random()*1000+1000);
           System.out.print("mhtOrderNo="+mhtOrderNo);
            map.put("mhtOrderNo","19831555");
            map.put("mhtReqTime", DateUtil.getStringFromDate(date, DateUtil.FORMAT_TRADETIME));
            map.put("nowPayOrderNo","200002201609131544530671334");
            map.put("iden","706018");

            requestReport = packages.returnMess(funcode,map);
            String xml = HttpPost.http("https://dby.ipaynow.cn/agentpay/receiveWithCode",requestReport) ;
            List list = unpack.unpack(xml, "utf-8");
            Map data = null;
            if("00".equals(list.get(0))){
                data = (Map)list.get(1);
            }
            System.out.print(data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
