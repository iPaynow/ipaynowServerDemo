package main.java.agent;


import main.java.util.DateUtil;
import main.java.util.HttpPost;

import java.util.*;

/**
 * 
 * @author WGH
 * Date: 16-10-13
 * Time: 上午10:40
 */

public class 代收交易 {
	/**
	 * 
	 *代收接入规则：
     *1.代收业务务必接入代收查询接口。
     *2.请求代收接口返回的结果务必以交易状态为准，返回的状态码如果不为成功、失败、其余的均按照处理中的交易进行处理。
     *3.处理中的代收交易务必要通过查询接口来进行轮询查询认证。直到返回终态（成功或失败）。
     *4.请求代收接口时，务必要记录请求和应答的相关日志。
	 * @param args
	 */
    public static void main(String[] args){
        Packages packages = new Packages();
        Unpack unpack = new Unpack();
        Map<String,String> map = new HashMap<String, String>();
        try {
            String requestReport = "";
            Date date = new Date();
            String funcode = "AP03";
            String mhtOrderNo = "Num"+(int)(Math.random()*1000+1000)+""+(int)(Math.random()*1000+1000);
            System.out.println(mhtOrderNo);
            map.put("mhtOrderNo", mhtOrderNo);
            map.put("mhtReqTime",DateUtil.getStringFromDate(date, DateUtil.FORMAT_TRADETIME));
            map.put("agentPayAccId","200001201611031203070989266");
            map.put("mhtOrderAmt","2021");
            map.put("agentPayMemo","测试代收交易");

            requestReport = packages.returnMess(funcode,map);
            String xml = HttpPost.http("https://dby.ipaynow.cn/agentpay/receiveWithoutCode",requestReport) ;
            List list = unpack.unpack(xml, "utf-8");
            Map data = null;
            if("00".equals(list.get(0))){
                data = (Map)list.get(1);
            }
            System.out.print(data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
