package main.java.agent;


import main.java.config.Config;
import main.java.util.*;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Twar3
 * Date: 14-12-30
 * Time: 下午9:11
 * To change this template use File | Settings | File Templates.
 */
public class Unpack {

    /**
     * 解密报文
     * @param dataStr 报文串
     * @param charset 编码字符集
     * @return
     */
    public List unpack(String dataStr, String charset){
        List respList = new ArrayList();

        try{
            dataStr = java.net.URLDecoder.decode(dataStr,charset);
            dataStr = dataStr.replaceAll(" ", "+");
        }catch (Exception e){
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }

        String resp_code ;//响应码
        String code ;//功能代码
        String data ;//3DES的串
        String sign ;//MD5的签名

        String DSEKey = Config.DSEKey;//3DES需要的key
        String MD5Key = Config.MD5Key;//MD5需要的key

        //logger.info("请求的数据做解析base64");
        respList = this.base(dataStr);
        resp_code = (String)respList.get(0);
        if(!"00".equals(resp_code)){
            respList.clear();
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }
        code = (String)respList.get(1);
        data = (String)respList.get(2);
        sign = (String)respList.get(3);

        if("0".equals(code)){
            respList.clear();
            respList.add("01");
            respList.add(data);
            return respList;
        }

        //logger.info("解析3DES密文");
        respList = this.DESMessage(data,DSEKey);
        resp_code = (String)respList.get(0);
        if(!"00".equals(resp_code)){
            respList.clear();
            respList.add("01");
            respList.add(data);
            return respList;
        }
        Map<String, String> dataMap = (Map<String, String>)respList.get(1);

        //logger.info("验证MD5签名");
        respList = this.MD5Message(dataMap,MD5Key,sign);
        resp_code = (String)respList.get(0);
        if(!"00".equals(resp_code)){
            respList.clear();
            respList.add("01");
            respList.add(data);
            return respList;
        }
        respList.clear();
        respList.add(resp_code);
        respList.add(dataMap);
        return respList;
    }

    /**
     * 解base64编码的串
     * @param dataStr 数据
     * @return
     */
    private List<String> base(String dataStr){
        List<String> respList = new ArrayList<String>();

        String code ;//临时存储第一部分
        String data = "";//功能代码
        String md5 = "";//机构码

        try{
            if(dataStr==null||"".equals(dataStr)){
                //logger.info("解析base64失败");
                respList.add("01");
                respList.add("");
                return respList;
            }

            //logger.info("切分请求字符串三部分");
            String[]  st = dataStr.split("\\|");
            code = st[0];

            if("1".equals(code)){
                data = st[1];
                md5 = new String(BASE64.decode(st[2]));
            }
            if("0".equals(code)){
                data = st[1];
            }
            respList.add("00");
            respList.add(code);
            respList.add(data);
            respList.add(md5);
        }catch (Exception e){
            //logger.error("解析base64失败",e);
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }
        return respList;
    }

    /**
     * 解密3DES密文
     * @param DSEStr 3DES密文
     * @param DSEKey 3DES的key
     * @return
     */
    private List DESMessage(String DSEStr,String DSEKey){
        List respList = new ArrayList();
        Map<String,String> map = new HashMap<String, String>();
        if(DSEStr==null||DSEKey==null){
            //logger.info("3DESC密文或者密钥为空");
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }
        String str =EncryDecryUtils.decryptFromBase64DES(DSEKey, DSEStr).trim();//存储3DES解密的原文
   System.out.println(str);
        if(str==null||"".equals(str)){
            //logger.info("3DESC原文为空");
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }
        try {
            map = ReportParser.parseFormDataPatternReport(str, "utf-8");
        }catch (Exception e){
            //logger.error("将3DES原文放入Map出错",e);
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }

        respList.add("00");
        respList.add(map);
        return respList;
    }

    /**
     * 验证签名
     * @param map 数据
     * @param MD5Key MD5 key
     * @param sign 报文签名串
     * @return
     */
    private List<String> MD5Message(Map<String,String> map,String MD5Key,String sign){
        List<String> respList = new ArrayList<String>();
        if(map==null){
            //logger.info("验证签名时原始数据为空");
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }
        if(sign==null||"".equals(sign)){
            //logger.info("原始签名为空");
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }

        String toRSAStr = FormDateReportConvertor.postFormLinkReport(map);

        try {
            String signNow = MD5.md5(toRSAStr + MD5Key, "utf-8");
            if(!sign.equalsIgnoreCase(signNow)){
                //logger.info("签名验证失败");
                //logger.info("待生成签名的串：" + toRSAStr);
                //logger.info("系统存储的key：" + MD5Key);
                //logger.info("生成的签名串：" + signNow);
                //logger.info("商户的签名串：" + sign);
                respList.add("01");
                respList.add("报文解析失败");
                return respList;
            }
        }catch (Exception e){
            //logger.error("签名验证出错",e);
            respList.add("01");
            respList.add("报文解析失败");
            return respList;
        }
        respList.add("00");
        return respList;
    }
    public static void main(String[] args) {
    	//3des解密
         Unpack u=new Unpack();
         u.DESMessage("pk29Iy3EhvzDyszusNjM5liWLgY0iAuxPyWkM1ccrmo40Y1GSEMc/fo1keH+H57Ag8DWduHsUHl1R038/oLTkpn3+QmSO3kqfhCvVqGQqdoZiyHKMnKUjckA/1HX0X9Fb5hLaKJIT1IE+Q1ycPQc/KNLnm7OWuTJMQFENVs8PdNRn0pqJ/3+9f2iY86qDuWEs1Ffgi+s+JVAQ9uqLhLt7g==","QEpJz6mM2JymJ6MtrtDBCESf");
    }

}
