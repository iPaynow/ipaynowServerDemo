package main.java.agent;

import main.java.config.Config;
import main.java.util.*;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Twar3
 * Date: 15-1-2
 * Time: 下午12:12
 * To change this template use File | Settings | File Templates.
 */
public class Packages {


    /**
     * 返回串
     * @param funcode 机构号
     * @param dataMap 返回信息
     * @return
     */
    public String returnMess(String funcode, Map dataMap) throws Exception{
        StringBuilder return_mess = new StringBuilder("funcode=" + funcode + "&message=");
        StringBuilder message = new StringBuilder();
        String temp ;
        String srt1;
        String srt2;
        String srt3;

        String DSEKey = Config.DSEKey;//3DES需要的key
        String MD5Key = Config.MD5Key;//MD5需要的key
        srt1 = this.base("appId=" +  Config.appId);
        dataMap = MapUtils.mapRemoveNull(dataMap);
        String dataStr = FormDateReportConvertor.postFormLinkReport(dataMap);//参数数据

        srt2 = EncryDecryUtils.encryptFromDESBase64(DSEKey.trim(), dataStr.trim());

        srt3 = this.MD5Message(dataStr, MD5Key);
        srt3 = this.base(srt3);

        
        System.out.println("str1="+srt1);
        System.out.println("str2="+srt2);
        System.out.println("str3="+srt3);
        
        message.append(srt1);  
        message.append("|");
        message.append(srt2); //拼接返回报文
        message.append("|");
        message.append(srt3);

        System.out.println(message.toString());
     //   return_mess.append(URLEncoder.encode(message.toString(), "UTF-8"));
        return_mess.append(message.toString());
        System.out.println(return_mess.toString());
        System.out.println(URLDecoder.decode(return_mess.toString(),"UTF-8"));
        return return_mess.toString();
    }

    /**
     * 将数据进行base64加密
     * @param dataStr 数据
     * @return
     */
    private String base(String dataStr){
        String return_mess = "";
        return_mess = BASE64.encode(dataStr.getBytes());
        return return_mess;
    }

    /**
     * 生成MD5签名
     * @param dataStr 数据
     * @param MD5Key MD5 key
     * @return
     */
    private String MD5Message(String dataStr, String MD5Key){
        String signNow ;
        try {
            if(dataStr==null || "".equals(dataStr)){
                return "";
            }
            System.out.println(dataStr+MD5Key);
            signNow = MD5.md5(dataStr + MD5Key, "utf-8");

        }catch (Exception e){
            return "";
        }
        return signNow;
    }

    public static void main(String[] args) throws Exception{
        String str = "appId=1409801351286401&cardIdenType=123456777754543532523&cardNo=55555555&cardOwner=李旭朋&cardPhoneNo=15838393970&cardType=0001&funcode=AP01&mhtOrderNo=2222222&mhtReqTime=20151209103656&mhtUserCardId=44444444&mhtUserId=333333vtnkfo3TchHUHshxw2lehzQUK0Lh03Nz";
        System.out.println( MD5.md5(str, "utf-8"));
    }
}
