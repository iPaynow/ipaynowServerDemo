package main.java.agent;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import main.java.util.DateUtil;
import main.java.util.HttpPost;

/**
 * 
 * @author WGH
 * Date: 16-10-13
 * Time: 上午10:40
 */

public class 账户余额查询 {

    public static void main(String[] args){
        Packages packages = new Packages();
        Unpack unpack = new Unpack();
        Map<String,String> map = new HashMap<String, String>();
        try {
            String requestReport = "";
            Date date = new Date();

            String funcode = "AP05";
            map.put("mhtReqTime",DateUtil.getStringFromDate(date, DateUtil.FORMAT_TRADETIME));
            map.put("mhtOrderNo","201608011738350001");
            map.put("accountType","AT01");



            requestReport = packages.returnMess(funcode,map);
            String xml = HttpPost.http("https://dby.ipaynow.cn/agentpay/accountBalanceQuery",requestReport) ;
            List list = unpack.unpack(xml, "utf-8");
            Map data = null;
            if("00".equals(list.get(0))){
                data = (Map)list.get(1);
            }
            System.out.print(data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
