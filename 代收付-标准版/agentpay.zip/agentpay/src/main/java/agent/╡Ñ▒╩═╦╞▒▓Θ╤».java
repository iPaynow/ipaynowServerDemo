package main.java.agent;


import main.java.util.HttpPost;

import java.util.*;

/**
 * 
 * @author 	WGH
 * Date: 16-10-13
 * Time: 上午10:40
 */

public class 单笔退票查询 {

    public static void main(String[] args){
        Packages packages = new Packages();
        Unpack unpack = new Unpack();
        Map<String,String> map = new HashMap<String, String>();
        try {
            String requestReport = "";
            Date date = new Date();

            String funcode = "AP13";
            map.put("mhtOrderNo","Num17691157");
            map.put("mhtReqTime", "20161013103742");
            
            requestReport = packages.returnMess(funcode,map);
            String xml = HttpPost.http("https://dby.ipaynow.cn/agentpay/agentPayRefundQuery",requestReport) ;
            List list = unpack.unpack(xml, "utf-8");
            Map data = null;
            if("00".equals(list.get(0))){
                data = (Map)list.get(1);
            }
            System.out.print(data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
