package main.java.agent;

import main.java.util.DateUtil;
import main.java.util.HttpPost;

import java.util.*;

/**
 * 
 * @author WGH
 * Date: 16-10-13
 * Time: 上午10:40
 */

public class 白名单 {

    public static void main(String[] args){
        Packages packages = new Packages();
        Unpack unpack = new Unpack();
        Map<String,String> map = new HashMap<String, String>();
        try {
            String requestReport = "";
            Date date = new Date();

            String funcode = "AP01";
          // String mhtOrderNo = Math.random() + date.toString();
            String mhtOrderNo="CS"+(int)(Math.random()*1000+1000)+""+(int)(Math.random()*1000+1000);
            System.out.println("mhtOrderNo="+mhtOrderNo);
            map.put("accType","0");
            map.put("mhtOrderNo",mhtOrderNo);
            map.put("mhtReqTime", DateUtil.getStringFromDate(date, DateUtil.FORMAT_TRADETIME));
            map.put("mhtUserId","wgh_12345");
            map.put("mhtUserCardId","wgh_12345_1");
            map.put("cardType","0001");
            map.put("cardIdenType","0001");
            map.put("cardOwner","王中王");
            map.put("cardNo","6226200115151456");
            map.put("cardIdenNo","230128199207081212");
            map.put("cardPhoneNo","13264177650");

            requestReport = packages.returnMess(funcode,map);
            String xml = HttpPost.http("https://dby.ipaynow.cn/agentpay/whiteListCollect",requestReport) ;
            List list = unpack.unpack(xml, "utf-8");
            Map data = null;
            if("00".equals(list.get(0))){
                data = (Map)list.get(1);
            }
            System.out.println("------------------应答信息---------------------------"+"\n"+xml+"------------------应答信息---------------------------");
            System.out.print(data);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
