package main.java;

/**
 * Created with IntelliJ IDEA.
 * User: 树强
 * Date: 15-12-24
 * Time: 下午7:42
 * To change this template use File | Settings | File Templates.
 */
public class Test {

    public static void main(String[] args) {
        String s  = "2PyvRMe6EoQNyZhS48md0iIey1hO4Mh2qfQ4pKvzOlBgO2u712+vmYd/57VF73IumO1c7RtZEGlM\n" +
                "p0vEuLeo6UzoSO90RS85dMqI/MVvob/Yh2JUJLk52F7UlqB16Gxj6sIjk9GU1lFeFZTbziVbRrVb\n" +
                "l48T8xByudeimw70Nx9d8+i6xozBrq8BoH0m7PkKbAPHmZquEm+F6AcoMM0IH2kijUzG7LB1iDSb\n" +
                "yfBKn3ObRF0Rul0Y470mKB87Rzfv";
        String s2  = "2PyvRMe6EoQNyZhS48md0iIey1hO4Mh2qfQ4pKvzOlBgO2u712+vmYd/57VF73IumO1c7RtZEGlM\n" +
                "p0vEuLeo6UzoSO90RS85dMqI/MVvob/Yh2JUJLk52F7UlqB16Gxj6sIjk9GU1lFeFZTbziVbRrVb\n" +
                "l48T8xByudeimw70Nx9d8+i6xozBrq8BoH0m7PkKbAPHmZquEm+F6AcoMM0IH2kijUzG7LB1iDSb\n" +
                "yfBKn3ObRF0Rul0Y470mKB87Rzfv";
        System.out.println(s.equals(s2));
    }

}
