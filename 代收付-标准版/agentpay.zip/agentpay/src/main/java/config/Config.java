package main.java.config;

/**
 * Created with IntelliJ IDEA.
 * User: 树强
 * Date: 15-12-30
 * Time: 下午1:40
 * To change this template use File | Settings | File Templates.
 */
public class Config {


    //测试
    public static String DSEKey = "e2KSP6awXjkbfm8eR3iE2BmW";//3DES需要的key
    public static String MD5Key = "oAKsBv38CcLdnIn5N733oiY81erfotAC";//MD5需要的key
    public static String appId="1459846530407363";
	
}
