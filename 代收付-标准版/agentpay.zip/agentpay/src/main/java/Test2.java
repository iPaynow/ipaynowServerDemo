package main.java;

import java.awt.*;
import javax.swing.*;
public class Test2 extends JFrame
{
 public static void main(String[] args)
 {
  Test2 a = new Test2();
 }
 
 public Test2()
 {
  JButton a1 = new JButton("白名单采集");
  JButton a2 = new JButton("西");
  JButton a3 = new JButton("南");
  JButton a4 = new JButton("北");
  JButton a5 = new JButton("中");
  this.add(a1, BorderLayout.EAST);
  this.add(a2, BorderLayout.WEST);
  this.add(a3, BorderLayout.SOUTH);
  this.add(a4, BorderLayout.NORTH);
  this.add(a5, BorderLayout.CENTER);
  this.setTitle("边界布局BorderLayout");
  this.setSize(500, 400);
  this.setLocation(800, 600);
  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  this.setVisible(true);
 }
}