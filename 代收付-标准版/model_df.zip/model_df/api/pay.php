<?php

require_once '../conf/Config.php';
require_once '../services/Service.php';
require_once '../utils/Log.php';
/**
 * Created by PhpStorm.
 * User: John
 * Date: 2015/9/24
 * Time: 13:56
 */
class Check
{
    public function toCheck(){
        $req=array();
		$req["agentPayMemo"]="test";
        $req["funcode"]=config::CHECK_FUNCODE;
        $req["mhtOrderNo"]=date("YmdHis");
		$req["mhtReqTime"]=date("YmdHis");
		$req["payeeAccType"]="02";
		$req["payeeName"]="中国";
		$req["payeeCardNo"]="38511234864324000";
		$req["mhtOrderAmt"]="301";	

        $req_content=Services::buildAndSendCheckReq($req);
        Log::outLog("接口应答信息:",$req_content);
        echo $req_content;
    }
}
$api=new Check();
$api->toCheck();