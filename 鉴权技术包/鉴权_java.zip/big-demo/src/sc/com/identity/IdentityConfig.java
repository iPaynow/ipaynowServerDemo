package sc.com.identity;
public class IdentityConfig {
	/**
	 * 【测试环境】
	 **/
	public final static String appId  = "1441071499740581";
	public final static String md5Key = "DK96gnOB7EmVDDaHgLTLEZqVgP0H0nML";
	public final static String des3Key = "abnMX6YXHjBdesCsn2TD8b25";
	public final static String url = "https://dby.ipaynow.cn/identify";
	

}


	
	
	
	
	
	
