package sc.com.MobileNo;
public class MobileNoConfig {
	/**
	 * 【测试环境】
	 **/
	public final static String appId  = "1476788813528909";
	public final static String md5Key = "c4MlX9GJCi0YI5z3RvpK17wPlscFKpY1";
	public final static String des3Key = "hSbw2SwTFs3SdnyS3sijvarq";
	public final static String url = "https://dby.ipaynow.cn/identify";

}


	
	
	
	
	
	
