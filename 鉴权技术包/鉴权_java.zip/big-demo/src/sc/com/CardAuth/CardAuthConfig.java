package sc.com.CardAuth;

public class CardAuthConfig {
	/**
	 * 【测试环境】
	 **/

	
        //卡认证测试参数
		public final static String appId  = "1441071499740581";
		public final static String md5Key = "DK96gnOB7EmVDDaHgLTLEZqVgP0H0nML";
		public final static String des3Key = "Z5CbXbEaJA6CYRSDS5Ddsab6";
		public final static String url = "https://dby.ipaynow.cn/identify";
		
	
	
//	//会长的测试参数，勿动
//	public final static String appId  = "1469496547358169";
//	public final static String md5Key = "CWwsT3fTVkcI5NnKukXanSixWiFsyR6y";
//	public final static String des3Key = "E4ChzmF4GWP6tndhjGCHhnjx";
//	public final static String url = "https://s.ipaynow.cn/auth";
		
	

	
	

}
	

 	
	
	
	
	
	
